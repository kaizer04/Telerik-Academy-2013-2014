﻿namespace _03.Animals
{
    interface ISound
    {
        void ProduceSound();
    }
}
