### Run the projects in the following order:
  0. Connection string is in RockBands.Common 
  1. RockBands.Services - must be started at first
  2. RockBands.ConsoleClient - seed data in the database + consuming Web API Services

