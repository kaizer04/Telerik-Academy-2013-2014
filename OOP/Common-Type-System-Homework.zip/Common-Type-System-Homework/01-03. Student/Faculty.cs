﻿namespace _01_03.Student
{
    public enum Faculty
    {
        Philosophy, 
        Law, 
        Mathematics, 
        Phisics, 
        Business, 
        Management, 
        Telecommunications
    }
}
