﻿namespace _02.Bank
{
    public class Individual : Customer
    {
        public Individual(string name) 
            : base(name)
        {

        }
    }
}
