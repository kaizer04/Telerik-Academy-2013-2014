﻿namespace _01_03.Student
{
    public enum University
    {
        SU, 
        TU, 
        NBU, 
        UNSS,
        SoftUni
    }
}
