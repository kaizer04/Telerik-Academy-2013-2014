﻿// 03. Write an expression that calculates rectangle’s area by given width and height.

var width = 5;
var height = 6;
console.log("The rectangle’s area is: ", width * height);