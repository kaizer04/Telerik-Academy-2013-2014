﻿namespace Kitchen
{
    public class Bowl
    {
        public void Add(Vegetable vegetableToAdd)
        {
            // ..
        }
    }
}

