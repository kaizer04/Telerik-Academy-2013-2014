﻿//01. Write an expression that checks if given integer is odd or even.

var number = 7;
console.log((number % 2) === 0 ? "The number is even" : "The number is odd");