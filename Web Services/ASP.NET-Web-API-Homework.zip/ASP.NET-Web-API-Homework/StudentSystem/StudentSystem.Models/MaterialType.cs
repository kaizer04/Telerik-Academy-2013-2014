namespace StudentSystem.Models
{
    public enum MaterialType
    {
        Presentation,
        SourceCode,
        Document,
        Url
    }
}