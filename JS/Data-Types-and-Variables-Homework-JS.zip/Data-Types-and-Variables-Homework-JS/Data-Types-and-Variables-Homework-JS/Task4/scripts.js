﻿//04. Create null, undefined variables and try typeof on them.

var nullVar = null;
var undefinedVar = undefined;

console.log("nullVar is: " + typeof (str));
console.log("undefinedVar is: " + typeof (obj));