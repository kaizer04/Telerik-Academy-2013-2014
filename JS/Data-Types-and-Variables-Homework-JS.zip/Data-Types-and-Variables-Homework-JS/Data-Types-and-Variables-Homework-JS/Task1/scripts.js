﻿//01. Assign all the possible JavaScript literals to different variables.

var intLiteral = 1;
var floatLiteral = 1.5;
var boolLiteral = true;
var stringLiteral = "Hello";
var objectLiteral = {
    name: "Pesho",
    age: 35
};

var arrayLiteral = [1, 2, 3];

console.log(boolLiteral);