﻿
//02. Create a string variable with quoted text in it. For example: "How you doin'?", Joey said.



var str = "'How you doin'?', Joey said.";

console.log(str);