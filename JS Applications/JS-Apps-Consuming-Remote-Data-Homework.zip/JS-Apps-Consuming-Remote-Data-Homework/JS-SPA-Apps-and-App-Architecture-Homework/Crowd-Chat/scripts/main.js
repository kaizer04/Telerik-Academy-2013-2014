﻿(function () {
    require.config({
        paths: {
            'jquery': 'libs/jquery-2.1.1.min',
            'sammy': 'libs/sammy',
            'requestModule': 'libs/requestModule'
        }
    });

    require([], function () {

    })
}());