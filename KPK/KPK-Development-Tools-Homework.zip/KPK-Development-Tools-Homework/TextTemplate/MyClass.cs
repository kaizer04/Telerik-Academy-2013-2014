﻿using System;

namespace TextTemplate
{
    public class MyClass
    {
        public static void CountToTen()
        {
            Console.WriteLine("Count to ten!");
            Console.WriteLine(1);
            Console.WriteLine(2);
            Console.WriteLine(3);
            Console.WriteLine(4);
            Console.WriteLine(5);
            Console.WriteLine(6);
            Console.WriteLine(7);
            Console.WriteLine(8);
            Console.WriteLine(9);
            Console.WriteLine(10);
        }
    }
}