﻿namespace _01_03.Student
{
    public enum Speciality
    {
        Telecommunications, 
        Marketing, 
        Business, 
        Entrepreneurship, 
        Phisics, 
        Mathematics, 
        Informatics, 
        Law, 
        Philosophy
    }
}
