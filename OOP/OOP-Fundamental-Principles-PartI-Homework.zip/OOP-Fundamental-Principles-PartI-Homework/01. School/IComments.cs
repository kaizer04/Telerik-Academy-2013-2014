﻿namespace School
{
    public interface IComments
    {
        string Comments { get; set; }
 
    }
}
