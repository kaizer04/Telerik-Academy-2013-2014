﻿namespace StudentSystem.Common
{
    using System;
    using System.Linq;

    public static class ConnectionStrings
    {
        public const string StudentSystemConnectionString = @"Data Source=.;Initial Catalog=StudentSystem;Integrated Security=True";
    }
}