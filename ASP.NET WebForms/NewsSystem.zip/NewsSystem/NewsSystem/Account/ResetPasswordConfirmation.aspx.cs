﻿using System.Web.UI;

namespace NewsSystem.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}