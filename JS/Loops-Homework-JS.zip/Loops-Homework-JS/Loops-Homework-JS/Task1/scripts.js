﻿/* 01. Write a script that prints all the numbers from 1 to N */

var n = 100;
for (var i = 1; i <= n; i++) {
    console.log(i);    
}