﻿// 08. Write an expression that calculates trapezoid's area by given sides a and b and height h.

var sideA = 3;
var sideB = 6.7;
var height = 2.8;
var area = (sideA + sideB) / 2 * height;

console.log("The area is: " + area);