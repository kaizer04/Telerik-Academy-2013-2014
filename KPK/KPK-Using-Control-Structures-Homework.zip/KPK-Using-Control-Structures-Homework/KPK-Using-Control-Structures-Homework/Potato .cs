﻿namespace Kitchen
{
    public class Potato : Vegetable
    {
    }
}
