﻿namespace Kitchen
{
    public abstract class Vegetable
    {
        public void Cut()
        {
            // ..
        }

        public void Peel()
        {
            // ..
        }
    }
}