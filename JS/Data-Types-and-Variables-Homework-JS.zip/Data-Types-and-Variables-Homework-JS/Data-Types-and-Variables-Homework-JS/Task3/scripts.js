﻿//03. Try typeof on all variables you created.

var intLiteral = 1;
var floatLiteral = 1.5;
var boolLiteral = true;
var stringLiteral = "Hello";
var objectLiteral = {
    name: "Pesho",
    age: 35
};

var arrayLiteral = [1, 2, 3];

console.log(typeof (intLiteral));
console.log(typeof (floatLiteral));
console.log(typeof (boolLiteral));
console.log(typeof (stringLiteral));
console.log(typeof (objectLiteral));
console.log(typeof (arrayLiteral));
